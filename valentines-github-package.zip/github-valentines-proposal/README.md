# 💕 Valentine's Day Proposal Website

A romantic 3-page interactive website proposal for Shmyuktaa.

## ✨ Features

- 🎵 Auto-playing romantic music ("Can't Help Falling in Love" by Elvis Presley)
- 💕 3 beautiful pages with smooth transitions
- 📸 Embedded photos throughout
- 💖 Floating hearts animation
- 🎊 Confetti celebration on "Yes"
- 📱 Fully responsive (works on mobile & desktop)
- 🎯 Interactive "No" button that runs away

## 🚀 Live Website

Once deployed on GitHub Pages, your website will be live at:
```
https://YOUR-USERNAME.github.io/valentines-proposal
```

## 💌 Created with Love by Paul

Forever yours! 🫀💍

---

**Note:** This is a personal romantic proposal website. Please respect the privacy and love shared here. ❤️
